import Layout from "./components/Layout";
import "./index.css";

function App() {
  return (
    <div className="p-5">
      <Layout></Layout>
    </div>
  );
}

export default App;
