import * as fs from 'fs';

fs;

const port = process.env.PORT || 8080